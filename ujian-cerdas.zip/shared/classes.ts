export const CLASS_OPTIONS = [
  "Umum",
  "X",
  "XI",
  "XII",
  "X IPA 1",
  "X IPA 2",
  "X IPS 1",
  "X IPS 2",
  "XI IPA 1",
  "XI IPA 2",
  "XI IPS 1",
  "XI IPS 2",
  "XII IPA 1",
  "XII IPA 2",
  "XII IPS 1",
  "XII IPS 2",
  "Lainnya",
] as const;

export type ClassOption = (typeof CLASS_OPTIONS)[number];
