export type ScorableQuestion = { id: number; correctAnswer: string };

export function scoreAnswers(questions: ScorableQuestion[], answers: Record<string, string>) {
  const correct = questions.filter((question) => answers[String(question.id)] === question.correctAnswer).length;
  const score = questions.length ? Math.round((correct / questions.length) * 10000) / 100 : 0;
  return { score, correct, total: questions.length };
}
