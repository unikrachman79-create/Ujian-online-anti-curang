import { describe, expect, it } from "vitest";
import { scoreAnswers } from "@shared/exam";

describe("scoreAnswers", () => {
  const questions = [
    { id: 1, correctAnswer: "A" },
    { id: 2, correctAnswer: "C" },
    { id: 3, correctAnswer: "B" },
  ];

  it("menghitung jawaban benar dan nilai dua desimal", () => {
    expect(scoreAnswers(questions, { "1": "A", "2": "B", "3": "B" })).toEqual({ score: 66.67, correct: 2, total: 3 });
  });

  it("mengembalikan nilai nol saat tidak ada soal", () => {
    expect(scoreAnswers([], {})).toEqual({ score: 0, correct: 0, total: 0 });
  });
});
