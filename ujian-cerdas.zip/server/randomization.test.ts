import { describe, expect, it } from "vitest";
import { shuffleWithSeed } from "./db";

describe("shuffleWithSeed", () => {
  const items = [1, 2, 3, 4, 5, 6];

  it("menghasilkan urutan stabil untuk session key yang sama", () => {
    expect(shuffleWithSeed(items, "session-a")).toEqual(shuffleWithSeed(items, "session-a"));
    expect(shuffleWithSeed(items, "session-a").sort()).toEqual(items);
  });

  it("dapat membedakan urutan antarsesi tanpa mengubah isi", () => {
    expect(shuffleWithSeed(items, "session-a")).not.toEqual(shuffleWithSeed(items, "session-b"));
    expect(shuffleWithSeed(items, "session-b").sort()).toEqual(items);
  });
});
