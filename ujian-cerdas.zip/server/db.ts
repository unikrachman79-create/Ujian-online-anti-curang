import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { accessTokens, exams, InsertUser, questions, students, submissions, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (!Object.keys(updateSet).length) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getOwnerStats(ownerId: number) {
  const db = await getDb();
  if (!db) return { exams: 0, questions: 0, students: 0, submissions: 0, averageScore: 0 };
  const [examRows, questionRows, studentRows, submissionRows, averageRows] = await Promise.all([
    db.select({ value: sql<number>`count(*)` }).from(exams).where(eq(exams.ownerId, ownerId)),
    db.select({ value: sql<number>`count(*)` }).from(questions).where(eq(questions.ownerId, ownerId)),
    db.select({ value: sql<number>`count(*)` }).from(students).where(eq(students.ownerId, ownerId)),
    db.select({ value: sql<number>`count(*)` }).from(submissions).innerJoin(exams, eq(submissions.examId, exams.id)).where(eq(exams.ownerId, ownerId)),
    db.select({ value: sql<number>`coalesce(avg(${submissions.score}), 0)` }).from(submissions).innerJoin(exams, eq(submissions.examId, exams.id)).where(eq(exams.ownerId, ownerId)),
  ]);
  const numberValue = (rows: Array<{ value: unknown }>) => Number(rows[0]?.value ?? 0);
  return { exams: numberValue(examRows), questions: numberValue(questionRows), students: numberValue(studentRows), submissions: numberValue(submissionRows), averageScore: Math.round(numberValue(averageRows) * 10) / 10 };
}

function seededNumber(seed: string) {
  let hash = 2166136261;
  for (let index = 0; index < seed.length; index += 1) hash = Math.imul(hash ^ seed.charCodeAt(index), 16777619);
  return (hash >>> 0) / 4294967296;
}

export function shuffleWithSeed<T>(items: T[], seed: string) {
  const output = [...items];
  for (let index = output.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(seededNumber(`${seed}:${index}`) * (index + 1));
    [output[index], output[swapIndex]] = [output[swapIndex], output[index]];
  }
  return output;
}

export type PublicExam = Awaited<ReturnType<typeof getExamByCode>>;

async function getExamPayload(exam: typeof exams.$inferSelect, sessionKey: string, includeAnswers: boolean) {
  const db = await getDb();
  if (!db) return undefined;
  const rawQuestions = await db.select().from(questions).where(eq(questions.examId, exam.id)).orderBy(questions.orderNo);
  const ordered = exam.randomizeQuestions ? shuffleWithSeed(rawQuestions, `${sessionKey}:questions`) : rawQuestions;
  const prepared = ordered.map((question) => {
    const originalOptions = JSON.parse(question.optionsJson) as string[];
    const indexed = originalOptions.map((text, index) => ({ text, index }));
    const arranged = exam.randomizeOptions && question.questionType === "choice" ? shuffleWithSeed(indexed, `${sessionKey}:options:${question.id}`) : indexed;
    const originalAnswerIndex = question.correctAnswer ? question.correctAnswer.toUpperCase().charCodeAt(0) - 65 : -1;
    const answerIndex = arranged.findIndex((option) => option.index === originalAnswerIndex);
    return {
      id: question.id,
      questionText: question.questionText,
      questionType: question.questionType,
      options: arranged.map((option) => option.text),
      correctAnswer: includeAnswers && answerIndex >= 0 ? String.fromCharCode(65 + answerIndex) : undefined,
      imageUrl: question.imageUrl,
      points: question.points,
      topic: question.topic,
      difficulty: question.difficulty,
      orderNo: question.orderNo,
      optionOrder: arranged.map((option) => option.index),
    };
  });
  return { ...exam, questions: prepared };
}

export async function getExamByCode(shareCode: string, sessionKey = "public") {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(exams).where(eq(exams.shareCode, shareCode)).limit(1);
  if (!result[0]) return undefined;
  return getExamPayload(result[0], sessionKey, false);
}

export async function getExamByToken(token: string, sessionKey = "public") {
  const db = await getDb();
  if (!db) return undefined;
  const tokenRows = await db.select().from(accessTokens).where(eq(accessTokens.token, token)).limit(1);
  const access = tokenRows[0];
  if (!access || access.used || (access.expiresAt && access.expiresAt.getTime() < Date.now())) return undefined;
  const result = await db.select().from(exams).where(eq(exams.id, access.examId)).limit(1);
  if (!result[0]) return undefined;
  const payload = await getExamPayload(result[0], sessionKey, false);
  return payload ? { ...payload, tokenStudentCode: access.studentCode, tokenId: access.id } : undefined;
}

export async function getExamByIdForScoring(examId: number, sessionKey: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(exams).where(eq(exams.id, examId)).limit(1);
  if (!result[0]) return undefined;
  return getExamPayload(result[0], sessionKey, true);
}
