import { COOKIE_NAME } from "@shared/const";
import { CLASS_OPTIONS } from "@shared/classes";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getDb, getExamByCode, getExamByIdForScoring, getExamByToken, getOwnerStats } from "./db";
import { accessTokens, exams, notifications, questions, students, subjects, submissions, teachers } from "../drizzle/schema";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { nanoid } from "nanoid";
import { z } from "zod";
import { storagePut } from "./storage";

const optionSchema = z.array(z.string().min(1)).max(6);
const questionInput = z.object({
  questionText: z.string().min(1),
  questionType: z.enum(["choice", "essay"]).default("choice"),
  options: optionSchema.default([]),
  correctAnswer: z.string().optional().default(""),
  imageUrl: z.string().url().optional(),
  className: z.enum(CLASS_OPTIONS).default("Umum"),
  points: z.number().int().min(1).max(20).default(1),
  subjectId: z.number().int().optional(),
  teacherId: z.number().int().optional(),
  topic: z.string().default("Umum"),
  difficulty: z.enum(["Mudah", "Sedang", "Sulit"]).default("Sedang"),
  orderNo: z.number().int().positive().optional(),
});

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin" && ctx.user.role !== "user") throw new TRPCError({ code: "FORBIDDEN" });
  return next();
});

function escapeCsv(value: unknown) {
  return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    summary: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      const base = await getOwnerStats(ctx.user.id);
      if (!db) return { ...base, subjects: 0, teachers: 0 };
      const [subjectRows, teacherRows] = await Promise.all([
        db.select({ value: sql<number>`count(*)` }).from(subjects).where(and(eq(subjects.ownerId, ctx.user.id), eq(subjects.status, "active"))),
        db.select({ value: sql<number>`count(*)` }).from(teachers).where(and(eq(teachers.ownerId, ctx.user.id), eq(teachers.status, "active"))),
      ]);
      return { ...base, subjects: Number(subjectRows[0]?.value ?? 0), teachers: Number(teacherRows[0]?.value ?? 0) };
    }),
    recentSubmissions: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select({ id: submissions.id, studentName: submissions.studentName, studentCode: submissions.studentCode, score: submissions.score, submittedAt: submissions.submittedAt, examTitle: exams.title })
        .from(submissions).innerJoin(exams, eq(submissions.examId, exams.id)).where(eq(exams.ownerId, ctx.user.id)).orderBy(desc(submissions.submittedAt)).limit(10);
    }),
  }),
  exams: router({
    list: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(exams).where(eq(exams.ownerId, ctx.user.id)).orderBy(desc(exams.createdAt));
    }),
    create: adminProcedure.input(z.object({ title: z.string().min(1), subject: z.string().min(1), subjectId: z.number().int().optional(), teacherId: z.number().int().optional(), className: z.string().min(1), description: z.string().optional(), durationMinutes: z.number().int().min(5).max(300), antiCheat: z.boolean().default(true), randomizeQuestions: z.boolean().default(true), randomizeOptions: z.boolean().default(true), oneTimeTokenRequired: z.boolean().default(false) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database belum siap" });
      const shareCode = nanoid(8).toUpperCase();
      await db.insert(exams).values({ title: input.title, subject: input.subject, subjectId: input.subjectId ?? null, teacherId: input.teacherId ?? null, className: input.className, description: input.description ?? null, durationMinutes: input.durationMinutes, ownerId: ctx.user.id, antiCheat: input.antiCheat ? 1 : 0, randomizeQuestions: input.randomizeQuestions ? 1 : 0, randomizeOptions: input.randomizeOptions ? 1 : 0, oneTimeTokenRequired: input.oneTimeTokenRequired ? 1 : 0, shareCode });
      return { shareCode };
    }),
    publish: adminProcedure.input(z.object({ id: z.number().int(), status: z.enum(["draft", "published", "closed"]) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(exams).set({ status: input.status }).where(and(eq(exams.id, input.id), eq(exams.ownerId, ctx.user.id)));
      return { success: true };
    }),
  }),
  teachers: router({
    list: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(teachers).where(eq(teachers.ownerId, ctx.user.id)).orderBy(desc(teachers.createdAt));
    }),
    create: adminProcedure.input(z.object({ teacherCode: z.string().min(1), name: z.string().min(1), nip: z.string().optional(), email: z.string().email().optional(), phone: z.string().optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database belum siap" });
      await db.insert(teachers).values({ ownerId: ctx.user.id, teacherCode: input.teacherCode, name: input.name, nip: input.nip ?? null, email: input.email ?? null, phone: input.phone ?? null });
      return { success: true };
    }),
    setStatus: adminProcedure.input(z.object({ id: z.number().int(), status: z.enum(["active", "inactive"]) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(teachers).set({ status: input.status }).where(and(eq(teachers.id, input.id), eq(teachers.ownerId, ctx.user.id)));
      return { success: true };
    }),
  }),
  subjects: router({
    list: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select({ id: subjects.id, ownerId: subjects.ownerId, code: subjects.code, name: subjects.name, grade: subjects.grade, semester: subjects.semester, teacherId: subjects.teacherId, teacherName: teachers.name, description: subjects.description, color: subjects.color, status: subjects.status, createdAt: subjects.createdAt }).from(subjects).leftJoin(teachers, eq(subjects.teacherId, teachers.id)).where(eq(subjects.ownerId, ctx.user.id)).orderBy(desc(subjects.createdAt));
    }),
    create: adminProcedure.input(z.object({ code: z.string().min(1), name: z.string().min(1), grade: z.string().min(1), semester: z.enum(["Ganjil", "Genap"]), teacherId: z.number().int().optional(), description: z.string().optional(), color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).default("#5b5ce2") })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database belum siap" });
      await db.insert(subjects).values({ ownerId: ctx.user.id, code: input.code, name: input.name, grade: input.grade, semester: input.semester, teacherId: input.teacherId ?? null, description: input.description ?? null, color: input.color });
      return { success: true };
    }),
    setStatus: adminProcedure.input(z.object({ id: z.number().int(), status: z.enum(["active", "archived"]) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.update(subjects).set({ status: input.status }).where(and(eq(subjects.id, input.id), eq(subjects.ownerId, ctx.user.id)));
      return { success: true };
    }),
  }),
  questions: router({
    list: adminProcedure.input(z.object({ examId: z.number().int().optional() }).optional()).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(questions).where(input?.examId ? and(eq(questions.ownerId, ctx.user.id), eq(questions.examId, input.examId)) : eq(questions.ownerId, ctx.user.id)).orderBy(questions.orderNo);
    }),
    create: adminProcedure.input(questionInput.extend({ examId: z.number().int().optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(questions).values({ ownerId: ctx.user.id, examId: input.examId ?? null, subjectId: input.subjectId ?? null, teacherId: input.teacherId ?? null, questionText: input.questionText, questionType: input.questionType, optionsJson: JSON.stringify(input.options), correctAnswer: input.questionType === "essay" ? null : input.correctAnswer.toUpperCase(), imageUrl: input.imageUrl ?? null, className: input.className, points: input.points, topic: input.topic, difficulty: input.difficulty, orderNo: input.orderNo ?? 1 });
      if (input.examId) await db.update(exams).set({ questionCount: sql<number>`${exams.questionCount} + 1` }).where(and(eq(exams.id, input.examId), eq(exams.ownerId, ctx.user.id)));
      return { success: true };
    }),
    importMany: adminProcedure.input(z.object({ examId: z.number().int().optional(), items: z.array(questionInput).min(1) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(questions).values(input.items.map((item, index) => ({ ownerId: ctx.user.id, examId: input.examId ?? null, subjectId: item.subjectId ?? null, teacherId: item.teacherId ?? null, questionText: item.questionText, questionType: item.questionType, optionsJson: JSON.stringify(item.options), correctAnswer: item.questionType === "essay" ? null : item.correctAnswer.toUpperCase(), imageUrl: item.imageUrl ?? null, className: item.className, points: item.points, topic: item.topic, difficulty: item.difficulty, orderNo: item.orderNo ?? index + 1 })));
      if (input.examId) await db.update(exams).set({ questionCount: input.items.length }).where(and(eq(exams.id, input.examId), eq(exams.ownerId, ctx.user.id)));
      return { imported: input.items.length };
    }),
    uploadImage: adminProcedure.input(z.object({ filename: z.string().min(1), contentType: z.string().startsWith("image/"), base64: z.string().min(10) })).mutation(async ({ ctx, input }) => {
      const file = await storagePut(`${ctx.user.id}-question-images/${input.filename}`, Buffer.from(input.base64, "base64"), input.contentType);
      return file;
    }),
  }),
  students: router({
    list: adminProcedure.query(async ({ ctx }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select().from(students).where(eq(students.ownerId, ctx.user.id)).orderBy(desc(students.createdAt));
    }),
    create: adminProcedure.input(z.object({ studentCode: z.string().min(1), nisn: z.string().optional(), name: z.string().min(1), gender: z.enum(["L", "P"]).optional(), className: z.string().min(1), email: z.string().email().optional(), phone: z.string().optional() })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(students).values({ ownerId: ctx.user.id, studentCode: input.studentCode, nisn: input.nisn ?? null, name: input.name, gender: input.gender ?? null, className: input.className, email: input.email ?? null, phone: input.phone ?? null });
      return { success: true };
    }),
    importMany: adminProcedure.input(z.object({ items: z.array(z.object({ studentCode: z.string().min(1), nisn: z.string().optional(), name: z.string().min(1), gender: z.enum(["L", "P"]).optional(), className: z.string().min(1), email: z.string().email().optional(), phone: z.string().optional() })).min(1) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      await db.insert(students).values(input.items.map((item) => ({ ...item, ownerId: ctx.user.id, nisn: item.nisn ?? null, gender: item.gender ?? null, email: item.email ?? null, phone: item.phone ?? null })));
      return { imported: input.items.length };
    }),
  }),
  accessTokens: router({
    list: adminProcedure.input(z.object({ examId: z.number().int() })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      const exam = await db.select().from(exams).where(and(eq(exams.id, input.examId), eq(exams.ownerId, ctx.user.id))).limit(1);
      if (!exam[0]) throw new TRPCError({ code: "NOT_FOUND" });
      return db.select({ id: accessTokens.id, token: accessTokens.token, studentCode: accessTokens.studentCode, used: accessTokens.used, expiresAt: accessTokens.expiresAt, studentName: students.name, email: students.email, phone: students.phone }).from(accessTokens).leftJoin(students, eq(accessTokens.studentId, students.id)).where(eq(accessTokens.examId, input.examId)).orderBy(desc(accessTokens.createdAt));
    }),
    create: adminProcedure.input(z.object({ examId: z.number().int(), studentIds: z.array(z.number().int()).min(1), expiresHours: z.number().int().min(1).max(720).default(72) })).mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const exam = await db.select().from(exams).where(and(eq(exams.id, input.examId), eq(exams.ownerId, ctx.user.id))).limit(1);
      if (!exam[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Ujian tidak ditemukan" });
      const selected = await db.select().from(students).where(and(eq(students.ownerId, ctx.user.id), inArray(students.id, input.studentIds)));
      const expiresAt = new Date(Date.now() + input.expiresHours * 60 * 60 * 1000);
      const created: Array<{ token: string; studentCode: string; studentName: string; email: string | null; phone: string | null }> = [];
      for (const student of selected) {
        const token = nanoid(24);
        await db.insert(accessTokens).values({ examId: input.examId, studentId: student.id, studentCode: student.studentCode, token, expiresAt });
        const destinations = [student.email ? { channel: "email" as const, destination: student.email } : null, student.phone ? { channel: "whatsapp" as const, destination: student.phone } : null].filter(Boolean) as Array<{ channel: "email" | "whatsapp"; destination: string }>;
        if (destinations.length) await db.insert(notifications).values(destinations.map((item) => ({ ownerId: ctx.user.id, examId: input.examId, studentId: student.id, channel: item.channel, destination: item.destination, token, status: "ready" as const })));
        created.push({ token, studentCode: student.studentCode, studentName: student.name, email: student.email, phone: student.phone });
      }
      return { created };
    }),
  }),
  results: router({
    list: adminProcedure.input(z.object({ examId: z.number().int().optional() }).optional()).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select({ id: submissions.id, examId: submissions.examId, studentCode: submissions.studentCode, studentName: submissions.studentName, score: submissions.score, essayScore: submissions.essayScore, durationSeconds: submissions.durationSeconds, tabSwitches: submissions.tabSwitches, fullscreenExits: submissions.fullscreenExits, submittedAt: submissions.submittedAt, examTitle: exams.title }).from(submissions).innerJoin(exams, eq(submissions.examId, exams.id)).where(input?.examId ? and(eq(submissions.examId, input.examId), eq(exams.ownerId, ctx.user.id)) : eq(exams.ownerId, ctx.user.id)).orderBy(desc(submissions.submittedAt));
    }),
    exportCsv: adminProcedure.input(z.object({ examId: z.number().int().optional() }).optional()).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return "";
      const rows = await db.select({ studentCode: submissions.studentCode, studentName: submissions.studentName, score: submissions.score, essayScore: submissions.essayScore, durationSeconds: submissions.durationSeconds, tabSwitches: submissions.tabSwitches, submittedAt: submissions.submittedAt, examTitle: exams.title }).from(submissions).innerJoin(exams, eq(submissions.examId, exams.id)).where(input?.examId ? and(eq(submissions.examId, input.examId), eq(exams.ownerId, ctx.user.id)) : eq(exams.ownerId, ctx.user.id)).orderBy(desc(submissions.submittedAt));
      const header = "Nama Ujian,Kode Siswa,Nama Siswa,Nilai Objektif,Nilai Esai,Durasi (detik),Pindah Tab,Waktu Submit";
      const lines = rows.map((row) => [row.examTitle, row.studentCode, row.studentName, row.score, row.essayScore, row.durationSeconds, row.tabSwitches, row.submittedAt.toISOString()].map(escapeCsv).join(","));
      return [header, ...lines].join("\n");
    }),
    exportExcel: adminProcedure.input(z.object({ examId: z.number().int().optional() }).optional()).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return "";
      const rows = await db.select({ studentCode: submissions.studentCode, studentName: submissions.studentName, score: submissions.score, essayScore: submissions.essayScore, durationSeconds: submissions.durationSeconds, tabSwitches: submissions.tabSwitches, fullscreenExits: submissions.fullscreenExits, submittedAt: submissions.submittedAt, examTitle: exams.title }).from(submissions).innerJoin(exams, eq(submissions.examId, exams.id)).where(input?.examId ? and(eq(submissions.examId, input.examId), eq(exams.ownerId, ctx.user.id)) : eq(exams.ownerId, ctx.user.id)).orderBy(desc(submissions.submittedAt));
      const rowsAsTsv = rows.map((row) => [row.examTitle, row.studentCode, row.studentName, row.score, row.essayScore, row.durationSeconds, row.tabSwitches, row.fullscreenExits, row.submittedAt.toISOString()].join("\t"));
      return ["Nama Ujian\tKode Siswa\tNama Siswa\tNilai Objektif\tNilai Esai\tDurasi (detik)\tPindah Tab\tKeluar Fullscreen\tWaktu Submit", ...rowsAsTsv].join("\n");
    }),
    reportData: adminProcedure.input(z.object({ examId: z.number().int().optional() }).optional()).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return { rows: [], byClass: [] };
      const rows = await db.select({ studentCode: submissions.studentCode, studentName: submissions.studentName, score: submissions.score, essayScore: submissions.essayScore, submittedAt: submissions.submittedAt, examTitle: exams.title, className: students.className }).from(submissions).innerJoin(exams, eq(submissions.examId, exams.id)).leftJoin(students, and(eq(submissions.studentCode, students.studentCode), eq(students.ownerId, ctx.user.id))).where(input?.examId ? and(eq(submissions.examId, input.examId), eq(exams.ownerId, ctx.user.id)) : eq(exams.ownerId, ctx.user.id)).orderBy(desc(submissions.submittedAt));
      const groups = new Map<string, { className: string; total: number; average: number; highest: number }>();
      for (const row of rows) { const className = row.className || "Tanpa kelas"; const current = groups.get(className) ?? { className, total: 0, average: 0, highest: 0 }; current.total += 1; current.average += Number(row.score) + Number(row.essayScore); current.highest = Math.max(current.highest, Number(row.score) + Number(row.essayScore)); groups.set(className, current); }
      return { rows, byClass: Array.from(groups.values()).map((group) => ({ ...group, average: Math.round((group.average / group.total) * 10) / 10 })) };
    }),
  }),
  analysis: router({
    byExam: adminProcedure.input(z.object({ examId: z.number().int() })).query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];
      const exam = await db.select().from(exams).where(and(eq(exams.id, input.examId), eq(exams.ownerId, ctx.user.id))).limit(1);
      if (!exam[0]) throw new TRPCError({ code: "NOT_FOUND" });
      const qs = await db.select().from(questions).where(and(eq(questions.examId, input.examId), eq(questions.ownerId, ctx.user.id))).orderBy(questions.orderNo);
      const subs = await db.select().from(submissions).where(eq(submissions.examId, input.examId));
      const groupSize = Math.max(1, Math.floor(subs.length * 0.27));
      return qs.map((question) => {
        const correct = subs.filter((sub) => question.questionType === "choice" && question.correctAnswer && (JSON.parse(sub.answersJson) as Record<string, string>)[String(question.id)] === question.correctAnswer).length;
        const p = subs.length ? correct / subs.length : 0;
        const topIds = new Set(subs.slice().sort((a, b) => Number(b.score) - Number(a.score)).slice(0, groupSize).map((sub) => sub.id));
        const bottomIds = new Set(subs.slice().sort((a, b) => Number(a.score) - Number(b.score)).slice(0, groupSize).map((sub) => sub.id));
        const topCorrect = subs.filter((sub) => topIds.has(sub.id) && question.correctAnswer && (JSON.parse(sub.answersJson) as Record<string, string>)[String(question.id)] === question.correctAnswer).length;
        const bottomCorrect = subs.filter((sub) => bottomIds.has(sub.id) && question.correctAnswer && (JSON.parse(sub.answersJson) as Record<string, string>)[String(question.id)] === question.correctAnswer).length;
        const discrimination = groupSize ? (topCorrect - bottomCorrect) / groupSize : 0;
        return { id: question.id, number: question.orderNo, topic: question.topic, type: question.questionType, difficulty: question.difficulty, difficultyIndex: Math.round(p * 100), discriminationIndex: Math.round(discrimination * 100), status: question.questionType === "essay" ? "Perlu penilaian" : p >= 0.3 && p <= 0.85 && discrimination >= 0.2 ? "Baik" : "Perlu revisi" };
      });
    }),
  }),
  publicExam: router({
    getByCode: publicProcedure.input(z.object({ shareCode: z.string().min(4), sessionKey: z.string().min(8).optional() })).query(({ input }) => getExamByCode(input.shareCode.toUpperCase(), input.sessionKey ?? input.shareCode.toUpperCase())),
    getByToken: publicProcedure.input(z.object({ token: z.string().min(12), sessionKey: z.string().min(8).optional() })).query(({ input }) => getExamByToken(input.token, input.sessionKey ?? input.token)),
    submit: publicProcedure.input(z.object({ examId: z.number().int(), token: z.string().optional(), sessionKey: z.string().min(8), studentCode: z.string().min(1), studentName: z.string().min(1), answers: z.record(z.string(), z.string()), questionOrder: z.array(z.number().int()), optionOrder: z.record(z.string(), z.array(z.number().int())), durationSeconds: z.number().int().min(0), tabSwitches: z.number().int().min(0), fullscreenExits: z.number().int().min(0) })).mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR" });
      const examRows = await db.select().from(exams).where(eq(exams.id, input.examId)).limit(1);
      const exam = examRows[0];
      if (!exam) throw new TRPCError({ code: "NOT_FOUND", message: "Ujian tidak ditemukan" });
      let tokenRow: typeof accessTokens.$inferSelect | undefined;
      if (exam.oneTimeTokenRequired) {
        if (!input.token) throw new TRPCError({ code: "UNAUTHORIZED", message: "Ujian ini membutuhkan token akses sekali pakai" });
        const rows = await db.select().from(accessTokens).where(and(eq(accessTokens.token, input.token), eq(accessTokens.examId, exam.id))).limit(1);
        tokenRow = rows[0];
        if (!tokenRow || tokenRow.used || (tokenRow.expiresAt && tokenRow.expiresAt.getTime() < Date.now())) throw new TRPCError({ code: "FORBIDDEN", message: "Token tidak valid, sudah dipakai, atau kedaluwarsa" });
      }
      const payload = await getExamByIdForScoring(input.examId, input.sessionKey);
      if (!payload) throw new TRPCError({ code: "NOT_FOUND" });
      const choiceQuestions = payload.questions.filter((question) => question.questionType === "choice");
      const essayQuestions = payload.questions.filter((question) => question.questionType === "essay");
      const earned = choiceQuestions.filter((question) => input.answers[String(question.id)] === question.correctAnswer).reduce((sum, question) => sum + question.points, 0);
      const objectivePossible = choiceQuestions.reduce((sum, question) => sum + question.points, 0);
      const score = objectivePossible ? Math.round((earned / objectivePossible) * 10000) / 100 : 0;
      await db.insert(submissions).values({ examId: input.examId, studentId: tokenRow?.studentId ?? null, studentCode: input.studentCode, studentName: input.studentName, answersJson: JSON.stringify(input.answers), questionOrderJson: JSON.stringify(input.questionOrder), optionOrderJson: JSON.stringify(input.optionOrder), score: String(score), essayScore: "0", durationSeconds: input.durationSeconds, tabSwitches: input.tabSwitches, fullscreenExits: input.fullscreenExits });
      if (tokenRow) await db.update(accessTokens).set({ used: 1, usedAt: new Date() }).where(eq(accessTokens.id, tokenRow.id));
      try { await notifyOwner({ title: `Jawaban baru: ${input.studentName}`, content: `${exam.title} · nilai objektif ${score}% · ${essayQuestions.length} soal esai menunggu penilaian.` }); } catch { /* operational alert is best effort */ }
      return { score, correct: earned, total: objectivePossible, essayCount: essayQuestions.length };
    }),
  }),
});

export type AppRouter = typeof appRouter;
