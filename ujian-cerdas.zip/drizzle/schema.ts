import {
  decimal,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const teachers = mysqlTable("teachers", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  teacherCode: varchar("teacherCode", { length: 64 }).notNull(),
  name: varchar("name", { length: 180 }).notNull(),
  nip: varchar("nip", { length: 64 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  code: varchar("code", { length: 32 }).notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  grade: varchar("grade", { length: 64 }).notNull(),
  semester: mysqlEnum("semester", ["Ganjil", "Genap"]).default("Ganjil").notNull(),
  teacherId: int("teacherId"),
  description: text("description"),
  color: varchar("color", { length: 16 }).default("#5b5ce2").notNull(),
  status: mysqlEnum("status", ["active", "archived"]).default("active").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const exams = mysqlTable("exams", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  subjectId: int("subjectId"),
  teacherId: int("teacherId"),
  title: varchar("title", { length: 255 }).notNull(),
  subject: varchar("subject", { length: 120 }).notNull(),
  className: varchar("className", { length: 80 }).notNull(),
  description: text("description"),
  durationMinutes: int("durationMinutes").default(60).notNull(),
  questionCount: int("questionCount").default(0).notNull(),
  antiCheat: int("antiCheat").default(1).notNull(),
  randomizeQuestions: int("randomizeQuestions").default(1).notNull(),
  randomizeOptions: int("randomizeOptions").default(1).notNull(),
  oneTimeTokenRequired: int("oneTimeTokenRequired").default(0).notNull(),
  status: mysqlEnum("status", ["draft", "published", "closed"]).default("draft").notNull(),
  shareCode: varchar("shareCode", { length: 32 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const questions = mysqlTable("questions", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  examId: int("examId"),
  subjectId: int("subjectId"),
  teacherId: int("teacherId"),
  questionText: text("questionText").notNull(),
  questionType: mysqlEnum("questionType", ["choice", "essay"]).default("choice").notNull(),
  optionsJson: text("optionsJson").notNull(),
  correctAnswer: varchar("correctAnswer", { length: 8 }),
  imageUrl: varchar("imageUrl", { length: 500 }),
  className: varchar("className", { length: 80 }).default("Umum").notNull(),
  points: int("points").default(1).notNull(),
  topic: varchar("topic", { length: 120 }).notNull(),
  difficulty: mysqlEnum("difficulty", ["Mudah", "Sedang", "Sulit"]).default("Sedang").notNull(),
  orderNo: int("orderNo").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  studentCode: varchar("studentCode", { length: 64 }).notNull(),
  nisn: varchar("nisn", { length: 32 }),
  name: varchar("name", { length: 180 }).notNull(),
  gender: mysqlEnum("gender", ["L", "P"]),
  className: varchar("className", { length: 80 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 32 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const accessTokens = mysqlTable("accessTokens", {
  id: int("id").autoincrement().primaryKey(),
  examId: int("examId").notNull(),
  studentId: int("studentId"),
  studentCode: varchar("studentCode", { length: 64 }).notNull(),
  token: varchar("token", { length: 80 }).notNull().unique(),
  used: int("used").default(0).notNull(),
  expiresAt: timestamp("expiresAt"),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  ownerId: int("ownerId").notNull(),
  examId: int("examId").notNull(),
  studentId: int("studentId"),
  channel: mysqlEnum("channel", ["email", "whatsapp"]).notNull(),
  destination: varchar("destination", { length: 320 }).notNull(),
  token: varchar("token", { length: 80 }).notNull(),
  status: mysqlEnum("status", ["ready", "sent"]).default("ready").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  sentAt: timestamp("sentAt"),
});

export const submissions = mysqlTable("submissions", {
  id: int("id").autoincrement().primaryKey(),
  examId: int("examId").notNull(),
  studentId: int("studentId"),
  studentCode: varchar("studentCode", { length: 64 }).notNull(),
  studentName: varchar("studentName", { length: 180 }).notNull(),
  answersJson: text("answersJson").notNull(),
  questionOrderJson: text("questionOrderJson"),
  optionOrderJson: text("optionOrderJson"),
  score: decimal("score", { precision: 5, scale: 2 }).default("0").notNull(),
  essayScore: decimal("essayScore", { precision: 5, scale: 2 }).default("0").notNull(),
  durationSeconds: int("durationSeconds").default(0).notNull(),
  tabSwitches: int("tabSwitches").default(0).notNull(),
  fullscreenExits: int("fullscreenExits").default(0).notNull(),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Teacher = typeof teachers.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type Exam = typeof exams.$inferSelect;
export type Question = typeof questions.$inferSelect;
export type Student = typeof students.$inferSelect;
export type AccessToken = typeof accessTokens.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type Submission = typeof submissions.$inferSelect;
