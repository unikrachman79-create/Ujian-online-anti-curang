CREATE TABLE `subjects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`code` varchar(32) NOT NULL,
	`name` varchar(120) NOT NULL,
	`grade` varchar(64) NOT NULL,
	`semester` enum('Ganjil','Genap') NOT NULL DEFAULT 'Ganjil',
	`teacherId` int,
	`description` text,
	`color` varchar(16) NOT NULL DEFAULT '#5b5ce2',
	`status` enum('active','archived') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `subjects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `teachers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`teacherCode` varchar(64) NOT NULL,
	`name` varchar(180) NOT NULL,
	`nip` varchar(64),
	`email` varchar(320),
	`phone` varchar(32),
	`status` enum('active','inactive') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `teachers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `exams` ADD `subjectId` int;--> statement-breakpoint
ALTER TABLE `exams` ADD `teacherId` int;--> statement-breakpoint
ALTER TABLE `questions` ADD `subjectId` int;--> statement-breakpoint
ALTER TABLE `questions` ADD `teacherId` int;--> statement-breakpoint
ALTER TABLE `students` ADD `nisn` varchar(32);--> statement-breakpoint
ALTER TABLE `students` ADD `gender` enum('L','P');