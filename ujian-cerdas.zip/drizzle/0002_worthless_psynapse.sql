CREATE TABLE `accessTokens` (
	`id` int AUTO_INCREMENT NOT NULL,
	`examId` int NOT NULL,
	`studentId` int,
	`studentCode` varchar(64) NOT NULL,
	`token` varchar(80) NOT NULL,
	`used` int NOT NULL DEFAULT 0,
	`expiresAt` timestamp,
	`usedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `accessTokens_id` PRIMARY KEY(`id`),
	CONSTRAINT `accessTokens_token_unique` UNIQUE(`token`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`examId` int NOT NULL,
	`studentId` int,
	`channel` enum('email','whatsapp') NOT NULL,
	`destination` varchar(320) NOT NULL,
	`token` varchar(80) NOT NULL,
	`status` enum('ready','sent') NOT NULL DEFAULT 'ready',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`sentAt` timestamp,
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `questions` MODIFY COLUMN `correctAnswer` varchar(8);--> statement-breakpoint
ALTER TABLE `exams` ADD `randomizeQuestions` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `exams` ADD `randomizeOptions` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `exams` ADD `oneTimeTokenRequired` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `questions` ADD `questionType` enum('choice','essay') DEFAULT 'choice' NOT NULL;--> statement-breakpoint
ALTER TABLE `questions` ADD `imageUrl` varchar(500);--> statement-breakpoint
ALTER TABLE `questions` ADD `points` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `students` ADD `phone` varchar(32);--> statement-breakpoint
ALTER TABLE `submissions` ADD `questionOrderJson` text;--> statement-breakpoint
ALTER TABLE `submissions` ADD `optionOrderJson` text;--> statement-breakpoint
ALTER TABLE `submissions` ADD `essayScore` decimal(5,2) DEFAULT '0' NOT NULL;