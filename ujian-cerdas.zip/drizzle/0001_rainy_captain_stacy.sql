CREATE TABLE `exams` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`subject` varchar(120) NOT NULL,
	`className` varchar(80) NOT NULL,
	`description` text,
	`durationMinutes` int NOT NULL DEFAULT 60,
	`questionCount` int NOT NULL DEFAULT 0,
	`antiCheat` int NOT NULL DEFAULT 1,
	`status` enum('draft','published','closed') NOT NULL DEFAULT 'draft',
	`shareCode` varchar(32) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `exams_id` PRIMARY KEY(`id`),
	CONSTRAINT `exams_shareCode_unique` UNIQUE(`shareCode`)
);
--> statement-breakpoint
CREATE TABLE `questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`examId` int,
	`questionText` text NOT NULL,
	`optionsJson` text NOT NULL,
	`correctAnswer` varchar(8) NOT NULL,
	`topic` varchar(120) NOT NULL,
	`difficulty` enum('Mudah','Sedang','Sulit') NOT NULL DEFAULT 'Sedang',
	`orderNo` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`studentCode` varchar(64) NOT NULL,
	`name` varchar(180) NOT NULL,
	`className` varchar(80) NOT NULL,
	`email` varchar(320),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `students_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`examId` int NOT NULL,
	`studentId` int,
	`studentCode` varchar(64) NOT NULL,
	`studentName` varchar(180) NOT NULL,
	`answersJson` text NOT NULL,
	`score` decimal(5,2) NOT NULL DEFAULT '0',
	`durationSeconds` int NOT NULL DEFAULT 0,
	`tabSwitches` int NOT NULL DEFAULT 0,
	`fullscreenExits` int NOT NULL DEFAULT 0,
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `submissions_id` PRIMARY KEY(`id`)
);
