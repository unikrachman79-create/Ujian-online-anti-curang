import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { startLogin } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { BarChart3, BookOpen, ClipboardCheck, FileDown, FileQuestion, GraduationCap, LayoutDashboard, LogOut, PanelLeft, PenLine, Users } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";

const menuItems = [
  { icon: LayoutDashboard, label: "Ringkasan", path: "/" },
  { icon: ClipboardCheck, label: "Ujian saya", path: "/exams" },
  { icon: BookOpen, label: "Mata pelajaran", path: "/subjects" },
  { icon: GraduationCap, label: "Guru pengampu", path: "/teachers" },
  { icon: FileQuestion, label: "Bank soal", path: "/questions" },
  { icon: PenLine, label: "Input soal", path: "/questions/new" },
  { icon: Users, label: "Peserta", path: "/students" },
  { icon: FileDown, label: "Hasil ujian", path: "/results" },
  { icon: BarChart3, label: "Analisis", path: "/analysis" },
];
const SIDEBAR_WIDTH_KEY = "sidebar-width";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => Number(localStorage.getItem(SIDEBAR_WIDTH_KEY)) || 280);
  const { loading, user } = useAuth();
  useEffect(() => localStorage.setItem(SIDEBAR_WIDTH_KEY, String(sidebarWidth)), [sidebarWidth]);
  if (loading) return <DashboardLayoutSkeleton />;
  if (!user) {
    return <div className="flex min-h-screen items-center justify-center bg-[#10172a] p-6"><div className="w-full max-w-md rounded-3xl bg-white p-9 text-center shadow-2xl"><div className="mx-auto mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-[#5b5ce2] text-white"><ClipboardCheck className="h-7 w-7" /></div><h1 className="font-display text-2xl font-bold tracking-tight">Masuk ke Ujian Cerdas</h1><p className="mt-2 text-sm leading-6 text-muted-foreground">Kelola ujian, soal, peserta, dan hasil belajar dalam satu ruang kerja.</p><Button onClick={() => startLogin()} size="lg" className="mt-7 w-full rounded-xl bg-[#5b5ce2] shadow-lg shadow-indigo-200 hover:bg-[#4a4bca]">Masuk dengan akun saya</Button></div></div>;
  }
  return <SidebarProvider style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}><DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent></SidebarProvider>;
}

function DashboardLayoutContent({ children, setSidebarWidth }: { children: React.ReactNode; setSidebarWidth: (width: number) => void }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const activeMenuItem = menuItems.find((item) => item.path === location) ?? menuItems[0];

  useEffect(() => {
    const handleMove = (event: MouseEvent) => {
      if (!isResizing) return;
      const left = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const width = event.clientX - left;
      if (width >= 210 && width <= 400) setSidebarWidth(width);
    };
    const handleUp = () => setIsResizing(false);
    if (isResizing) {
      document.addEventListener("mousemove", handleMove);
      document.addEventListener("mouseup", handleUp);
      document.body.style.cursor = "col-resize";
    }
    return () => { document.removeEventListener("mousemove", handleMove); document.removeEventListener("mouseup", handleUp); document.body.style.cursor = ""; };
  }, [isResizing, setSidebarWidth]);

  return <>
    <div className="relative" ref={sidebarRef}>
      <Sidebar collapsible="icon" className="border-r-0 bg-[#10172a]" disableTransition={isResizing}>
        <SidebarHeader className="h-20 justify-center px-3"><div className="flex w-full items-center gap-3"><button onClick={toggleSidebar} className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/10 text-white hover:bg-white/20" aria-label="Toggle navigation"><PanelLeft className="h-4 w-4" /></button>{!isCollapsed && <div className="min-w-0"><p className="font-display text-sm font-bold tracking-tight text-white">Ujian Cerdas</p><p className="text-[11px] text-slate-400">Ruang kerja guru</p></div>}</div></SidebarHeader>
        <SidebarContent className="gap-0 px-2"><p className="px-3 pb-2 pt-4 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-500 group-data-[collapsible=icon]:hidden">Navigasi utama</p><SidebarMenu>{menuItems.map((item) => { const active = location === item.path; return <SidebarMenuItem key={item.path}><SidebarMenuButton isActive={active} onClick={() => setLocation(item.path)} tooltip={item.label} className={`h-11 rounded-xl font-medium transition-colors ${active ? "bg-[#5b5ce2] text-white hover:bg-[#5b5ce2] hover:text-white" : "text-slate-300 hover:bg-white/10 hover:text-white"}`}><item.icon className="h-[18px] w-[18px]" /><span>{item.label}</span></SidebarMenuButton></SidebarMenuItem>; })}</SidebarMenu><div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-3 group-data-[collapsible=icon]:hidden"><p className="text-xs font-semibold text-white">Tips anti-curang</p><p className="mt-1 text-[11px] leading-5 text-slate-400">Aktifkan mode fokus untuk mencatat perpindahan tab dan keluar layar penuh.</p></div></SidebarContent>
        <SidebarFooter className="p-3"><DropdownMenu><DropdownMenuTrigger asChild><button className="flex w-full items-center gap-3 rounded-xl px-1 py-2 text-left hover:bg-white/10 group-data-[collapsible=icon]:justify-center"><Avatar className="h-9 w-9 border border-white/10"><AvatarFallback className="bg-[#7375ed] text-xs font-bold text-white">{user?.name?.charAt(0).toUpperCase() || "G"}</AvatarFallback></Avatar><div className="min-w-0 flex-1 group-data-[collapsible=icon]:hidden"><p className="truncate text-sm font-semibold text-white">{user?.name || "Guru"}</p><p className="mt-0.5 truncate text-xs text-slate-400">{user?.email || "Akun aktif"}</p></div></button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-48"><DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive"><LogOut className="mr-2 h-4 w-4" />Keluar</DropdownMenuItem></DropdownMenuContent></DropdownMenu></SidebarFooter>
      </Sidebar>
      <div className={`absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-primary/30 ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => setIsResizing(true)} />
    </div>
    <SidebarInset className="bg-[#f7f8fc]">{isMobile && <div className="sticky top-0 z-40 flex h-14 items-center gap-2 border-b bg-white/90 px-3 backdrop-blur"><SidebarTrigger className="h-9 w-9 rounded-lg" /><span className="font-display text-sm font-bold">{activeMenuItem.label}</span></div>}<main className="min-h-screen flex-1 p-4 sm:p-6 lg:p-9">{children}</main></SidebarInset>
  </>;
}
