import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import DashboardLayout from "./components/DashboardLayout";
import { ThemeProvider } from "./contexts/ThemeContext";
import { QuestionInputPage, StudentsDashboardPage, SubjectsPage, TeachersPage } from "./pages/AcademicPages";
import ExamPage from "./pages/ExamPage";
import Home from "./pages/Home";
import NotFound from "./pages/NotFound";
import { AnalysisPage, ExamsPage, QuestionsPage, ReportPage, ResultsPage } from "./pages/Workspace";

function DashboardRoute({ children }: { children: React.ReactNode }) {
  return <DashboardLayout>{children}</DashboardLayout>;
}

function Router() {
  return <Switch>
    <Route path="/" component={() => <DashboardRoute><Home /></DashboardRoute>} />
    <Route path="/exams" component={() => <DashboardRoute><ExamsPage /></DashboardRoute>} />
    <Route path="/subjects" component={() => <DashboardRoute><SubjectsPage /></DashboardRoute>} />
    <Route path="/teachers" component={() => <DashboardRoute><TeachersPage /></DashboardRoute>} />
    <Route path="/questions" component={() => <DashboardRoute><QuestionsPage /></DashboardRoute>} />
    <Route path="/questions/new" component={() => <DashboardRoute><QuestionInputPage /></DashboardRoute>} />
    <Route path="/students" component={() => <DashboardRoute><StudentsDashboardPage /></DashboardRoute>} />
    <Route path="/results" component={() => <DashboardRoute><ResultsPage /></DashboardRoute>} />
    <Route path="/report" component={() => <DashboardRoute><ReportPage /></DashboardRoute>} />
    <Route path="/analysis" component={() => <DashboardRoute><AnalysisPage /></DashboardRoute>} />
    <Route path="/exam/:code" component={ExamPage} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><Router /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
